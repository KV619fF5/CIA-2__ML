import pickle 
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import pandas as pd


data = pd.read_csv(r'C:\Users\Kirthik\Downloads\train.csv')

X_train, X_test, y_train, y_test = train_test_split(data['comment_text'], data['toxic'], test_size=0.2, random_state=42)
 

tfidf = TfidfVectorizer(strip_accents='unicode', analyzer='word', ngram_range=(1, 3), norm='l2')
tfidf.fit(X_train)
 
X_train_tfidf = tfidf.transform(X_train)
X_test_tfidf = tfidf.transform(X_test)
 
lr = LogisticRegression(C=1.0, penalty='l2', random_state=42, solver='sag')
lr.fit(X_train_tfidf, y_train)
comment = data["comment_text"]
comment_tfidf = tfidf.transform(comment)
prediction = lr.predict(comment_tfidf)

with open('tfidf.pkl', 'wb') as f:
    pickle.dump(tfidf, f)
with open('model.pkl', 'wb') as f:
     pickle.dump(lr, f)