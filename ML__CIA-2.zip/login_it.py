import mysql.connector
'''
##mycursor.execute("CREATE DATABASE machine")
mycursor.execute("SHOW DATABASES")
res = mycursor.fetchall()
print(res)

mycursor.execute("USE machine")

mycursor.execute(
    """
    CREATE TABLE users(
        email VARCHAR(100),
        password VARCHAR(100)
    )
    """)
'''
mydb=mysql.connector.connect(
host="localhost",
user="root",
password="assassinkv6190f5", 
database="machine"  
)
mycursor=mydb.cursor()
def sqlsignup(e,p):
    mycursor.execute(f"SELECT email FROM users WHERE email='{e}'")
    if mycursor.fetchall():
        return False
    sql = "INSERT INTO users (email,password) VALUES ({}, {})".format(e,p)
    mycursor.execute(sql)
    mydb.commit()
    
def sqllogin(e,p):
    sql = "SELECT password FROM users WHERE email=%s"%e
    mycursor.execute(sql)
    pas = mycursor.fetchone()
    if not pas:
        print("no email found")
    elif pas[0]==p:
        print("hi ")
    else:
        print("please enter your correct password")