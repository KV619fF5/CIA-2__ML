from flask import Flask, render_template, redirect, request, session, url_for
from flask_session import Session
from login_it import sqlsignup
from login_it import sqllogin
from toxicitydetection_it import model
import pymysql
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import pickle


app=Flask(__name__)

lr = LogisticRegression()
f = open('model.pkl','rb')
lr = pickle.load(f)

tfidf = TfidfVectorizer()
f1 = open('tfidf.pkl', 'rb')
tfidf = pickle.load(f1)


@app.route('/')
@app.route('/page')
def index():
    return render_template('page.html')

@app.route("/login",methods=['POST','GET'])
def login():
    if request.method=='POST':
        e=request.form.get('email')
        p=request.form.get('password')
        return render_template('confirm.html',email=e,password=p)
    return render_template('page.html')
@app.route('/toxic',methods=['POST'])
def toxic():
    comment=request.form.get('input1')  
    
    comment_tfidf = tfidf.transform([comment])
    prediction = lr.predict(comment_tfidf)
    if prediction == 0:
        data="The comment is not toxic."
    else:
        data="The comment is toxic."
        
    return render_template('success.html', data=data)

if __name__ =="__main__":
    app.run(port=6900)